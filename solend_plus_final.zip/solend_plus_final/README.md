
# Solend+ (DeFi протокол на Solana)

## Возможности
- Lending (депозиты, займы)
- Yield Farming
- Governance (DAO)
- SL+ Token (mint, stake, голосование)

## Установка
```bash
git clone <your-repo>
cd solend_plus_final
anchor build
```

## Деплой
```bash
solana config set --url https://api.devnet.solana.com
anchor deploy
```

## Тесты
```bash
anchor test
```

## Структура
- programs/solend_plus/src/lib.rs — смарт-контракт
- tests/ — тесты
- Anchor.toml, Cargo.toml — конфиги
