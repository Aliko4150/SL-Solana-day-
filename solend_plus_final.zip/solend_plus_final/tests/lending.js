
const anchor = require("@project-serum/anchor");

describe("solend_plus lending", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);
  const program = anchor.workspace.SolendPlus;

  it("Deposits liquidity and mints SL+ tokens", async () => {
    console.log("Running deposit test...");
    // TODO: mock user accounts and vaults
  });
});
    