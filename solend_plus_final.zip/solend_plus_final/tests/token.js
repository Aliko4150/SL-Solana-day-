
const anchor = require("@project-serum/anchor");

describe("solend_plus SL+ token", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);
  const program = anchor.workspace.SolendPlus;

  it("Stakes SL+ tokens", async () => {
    console.log("Running staking test...");
    // TODO: mock staking vault
  });
});
    